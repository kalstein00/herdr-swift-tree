import{a,b,c,d}from"./grammar-KHHMJKVV.js";import"./grammar-MDGA75AX.js";import"./grammar-DDM77BFD.js";export{d as css,b as cssCompletionSource,c as cssLanguage,a as defineCSSCompletionSource};
