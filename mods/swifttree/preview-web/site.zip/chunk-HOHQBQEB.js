import{a,b,c,d}from"./chunk-KP5VFDTE.js";import"./chunk-3RNHDNP5.js";export{a as javascript,b as json,c as jsonld,d as typescript};
