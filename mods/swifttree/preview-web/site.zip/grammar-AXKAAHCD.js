import{a,b,c,d}from"./grammar-Z72AEOHJ.js";export{a as javascript,b as json,c as jsonld,d as typescript};
