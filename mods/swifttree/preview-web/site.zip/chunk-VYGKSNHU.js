import{a as o,b as m}from"./chunk-JYQXOALJ.js";import"./chunk-ZZGNK56T.js";import"./chunk-T4WWCC5Z.js";import"./chunk-QP3MATMC.js";import"./chunk-C4LPZGZA.js";import"./chunk-I22BIYCS.js";import"./chunk-QRIWHU5U.js";import"./chunk-SNMBC6G5.js";import"./chunk-QVYRKYKN.js";import"./chunk-3EDOM6GB.js";import"./chunk-GNN77QG7.js";import"./chunk-LQ2XFEUL.js";import"./chunk-V7JBXZRD.js";import"./chunk-NKHEVBLN.js";import"./chunk-HVVAQLXH.js";import"./chunk-6NDAIVIK.js";import"./chunk-NIYWVWMC.js";import"./chunk-P7PYPF75.js";import"./chunk-HZBWLQAJ.js";import"./chunk-PPXLQNBK.js";import"./chunk-Q2D2FFUK.js";import"./chunk-QKYC3Y57.js";import"./chunk-7K6SAGGZ.js";import{a as r}from"./chunk-YUSHYV7C.js";import"./chunk-3RNHDNP5.js";var i=r(t=>`${o(t)}
  .swimlane.cluster:not([data-color-id]) rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),e=i,b=m({styles:e});export{b as diagram};
