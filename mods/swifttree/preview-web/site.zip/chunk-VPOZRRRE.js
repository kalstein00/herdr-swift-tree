import{a as o,b as m}from"./chunk-T54TTRJC.js";import"./chunk-ZZGNK56T.js";import"./chunk-T4WWCC5Z.js";import"./chunk-QP3MATMC.js";import"./chunk-C4LPZGZA.js";import"./chunk-F7PO37WZ.js";import"./chunk-I5T3LSFI.js";import"./chunk-SNMBC6G5.js";import"./chunk-T5CQJ7IV.js";import"./chunk-LFBF33FT.js";import"./chunk-4EM6CH3N.js";import"./chunk-QXFUPOLA.js";import"./chunk-4VT4IIPJ.js";import"./chunk-HQHTEDGE.js";import"./chunk-HVVAQLXH.js";import"./chunk-6NDAIVIK.js";import"./chunk-SDOIBOIV.js";import"./chunk-OG63FPFK.js";import"./chunk-2VJ7IR5O.js";import"./chunk-PPXLQNBK.js";import"./chunk-DOOS6F3O.js";import"./chunk-7K6SAGGZ.js";import{a as r}from"./chunk-YUSHYV7C.js";import"./chunk-3RNHDNP5.js";var i=r(t=>`${o(t)}
  .swimlane.cluster:not([data-color-id]) rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),e=i,b=m({styles:e});export{b as diagram};
